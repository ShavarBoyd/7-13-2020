let name = "John"
/*:
Always remember that Xcode is a tool that is trying to give you a helpful suggestion, but it’s just a suggestion. Don’t accept a Fix-it without taking a moment to understand the change it is making.
 */
//: [Previous](@previous)  |  page 8 of 13  |  [Next: Safer Code in a Varying World](@next)
